from app import app

# Getting api key
api_key = app.config['MOVIE_API_KEY']


#Getting the movie bae url 

base_url = app.config["MOVIE_API_KEY"]

def get_movies(cartegory):
	'''
	Function that gets the json to our url request

	'''
	get_movies_url=base_url.format(cartegory,api_key)

	with urllib.request.urlopen(get_movies_url) as url:
		get_movies_data = url.read()
		get_movies_response = json.loads(get_movies_data)

		movies_result= None

		if get_movies_response['results']:
			movie_results_list = get_movies_response['results']
			movie_results = process_results(movie_results_list)

	return movie_results

def process_results(movie_list):
	