QTalarm
=======

A handy alarm clock Program written in QT.

Compile Instrustions for Linux and Mac:
  Type: "qmake", "make", and then "make clean"

Windows users will have to compile the program with the QT creator IDE (or download the binaries off the downloads page)

Screen shots and more information on the [offical web page!](https://random-hackery.net/page/qtalarm/)

Features
========

- Unlimted number of customizable alarms

- Can wake up using the default sound, or any of audio / video file of your choosing.

- Custom Date alarms

- Completely Cross plateform


Licensing
==========
GPL V3


Please Report any bugs to the github page at https://github.com/CountMurphy/QTalarm
