# for num in range(100):
#     string=""
#     if num % 3 == 0:
#         string = string + "Fizz"
#         if num % 5 ==0:
#             string = string +"Buzz"
#             if num % 5!=0 and num %3 !=0
#             string = string + str(num)
#             print(string)


for x in range(101):
   #
   if x % 15 == 0:
      print("FizzBuzz")
      continue

   if x % 3 == 0:
       print("Fizz")
       continue

   elif x % 5 == 0:
       print("Buzz")
       continue

       print(x)
