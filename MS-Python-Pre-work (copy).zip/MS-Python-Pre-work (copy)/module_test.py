greeting="Reign"
name="King Jesus"
prayer= """Yahwe, I thank you for this far You have brought me,
I am concious that I can't do without you,
and with you, impossible is nothing to me! Now that I have you, the devil will have to be ashamed because you have strengthened me and hid me below Your wings, You have cleansed me by Your only begotten Son, Jesus Christ! I
trust in Your power to save my King, I trust you with my life, and dream. Let it reign Lord as you Open the heavens for me. LOrd let it rain in my life, let Your power flow in me, Hallelujah, Amen. I love and adore you master!!
"""
print(greeting + ","+ name +"!" + prayer)
